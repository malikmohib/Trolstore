#import <Foundation/Foundation.h>
#import "AXEventPathInfoRepresentation.h"

@interface AXEventHandInfoRepresentation : NSObject
- (NSArray <AXEventPathInfoRepresentation *> *)paths;
@end