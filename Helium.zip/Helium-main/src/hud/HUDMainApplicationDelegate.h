#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUDMainApplicationDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

NS_ASSUME_NONNULL_END