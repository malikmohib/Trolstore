//
//  SelectPresetView.swift
//
//
//  Created by lemin on 12/15/23.
//

import Foundation
import SwiftUI

//struct SelectPresetView: View {
//    @StateObject var widgetManager: WidgetManager
//    @State var widgetSet: WidgetSetStruct
//    @Binding var isOpen: Bool
//    
//    var onChoice: (PresetStruct) -> ()
//    
//    var body: some View {
//        List {
//            ForEach(Preset.allCases, id: \.self) { id in
//                Button(action: {
//                    let newWidget = widgetManager.addWidget(widgetSet: widgetSet, module: id)
//                    isOpen = false
//                    onChoice(newWidget)
//                }) {
//                    Text(id.rawValue)
//                }
//            }
//        }
//    }
//}
